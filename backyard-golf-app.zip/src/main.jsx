import React from 'react';
import ReactDOM from 'react-dom/client';
import BackyardGolfApp from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BackyardGolfApp />
  </React.StrictMode>
);
